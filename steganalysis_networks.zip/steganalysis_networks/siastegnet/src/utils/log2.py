"""Implementation of customized logging configs."""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import logging
import logging.config

try:
    import coloredlogs
    COLOREDLOGS_AVAILABLE = True
except ImportError:
    COLOREDLOGS_AVAILABLE = False

__all__ = ['configure_logging']

def configure_logging(level=logging.INFO, file=None, mode='w', format=None, datefmt=None,
                      root_handler_type=1):
    """Configures logging.

    `console` can write colored messages to console.
    If `file` is specified, messages will also be written to the file.

    Args:
        level (int or string, optional): Logging level ('CRITICAL', 'ERROR',
            'WARNING', 'INFO', 'DEBUG', 'NOTSET').
        file (string, optional): Path to log file.
        mode (string, optional): Mode to open the log file (default: 'w').
        format (string, optional): Format of the log messages.
        datefmt (string, optional): Format of the log timestamps.
        root_handler_type (int, optional): 0: console + file, 1: console only, 2: file only.
    """
    if root_handler_type in (0, 2) and file is None:
        raise ValueError('file should be specified when root_handler_type is 0 or 2')

    if format is None:
        format = '%(asctime)s %(filename)s:%(lineno)d [%(process)d] %(levelname)s %(message)s'

    # 修正时间格式，避免 `ValueError: Invalid format string`
    if datefmt is None:
        datefmt = '%Y-%m-%d %H:%M:%S'  # 修正原来的 `'%Y-%m-%d %H:%M:%S.%f'`

    # 定义格式化器
    basic_formatters = {
        'console_formatter': {
            'format': format,
            'datefmt': datefmt
        }
    }

    # 如果 `coloredlogs` 可用，就使用它
    if COLOREDLOGS_AVAILABLE:
        basic_formatters['console_formatter']['()'] = 'coloredlogs.ColoredFormatter'

    # 处理器（handlers）
    basic_handlers = {
        'console_handler': {
            'class': 'logging.StreamHandler',
            'level': level,
            'formatter': 'console_formatter'
        }
    }

    extra_formatters = {}
    extra_handlers = {}

    # 如果需要文件日志
    if file is not None:
        extra_formatters = {
            'file_formatter': {
                'format': format,
                'datefmt': datefmt
            }
        }
        extra_handlers = {
            'file_handler': {
                'class': 'logging.FileHandler',
                'filename': file,
                'mode': mode,
                'level': level,
                'formatter': 'file_formatter'
            }
        }

    # 选择日志处理器类型
    if root_handler_type == 0:
        root_handlers = ['console_handler', 'file_handler']
    elif root_handler_type == 1:
        root_handlers = ['console_handler']
    elif root_handler_type == 2:
        root_handlers = ['file_handler']
    else:
        raise ValueError('root_handler_type can only be 0, 1, 2, but got {}'
                         .format(root_handler_type))

    # 合并日志格式器和处理器
    basic_formatters.update(extra_formatters)
    basic_handlers.update(extra_handlers)

    # 配置日志系统
    logging.config.dictConfig({
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': basic_formatters,
        'handlers': basic_handlers,
        'root': {
            'level': level,
            'handlers': root_handlers,
        }
    })
